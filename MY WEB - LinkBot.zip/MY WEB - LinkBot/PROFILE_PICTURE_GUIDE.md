# Profile Picture Setup Guide

## Where to Upload Your Bot Profile Picture

Your bot profile picture should be placed in the **`assets/`** folder of the Knightbot-MD project.

### Current Bot Pictures

Located at: `/assets/`

Current pictures in the assets folder:
- `bot_image.jpg` - Main bot profile image (this is used as the bot's avatar)
- `bmc_qr.png` - QR code image
- `stickintro.webp` - Sticker intro image
- `sticktag.webp` - Sticker tag image
- `thor.png` - Thor image

### How to Update the Bot Profile Picture

1. **Prepare your image:**
   - Recommended format: `.jpg` or `.png`
   - Recommended size: 512x512 pixels (square)
   - Recommended file size: Less than 500KB

2. **Place the image in the assets folder:**
   - Path: `Knightbot-MD-main/assets/bot_image.jpg`
   - Replace the existing `bot_image.jpg` with your image
   - Or rename your image to `bot_image.jpg` and replace the existing file

3. **If you want to use a different filename:**
   - Edit the main bot file (index.js or main.js) to reference the new filename
   - Or keep the filename as `bot_image.jpg` for consistency

### Steps to Replace the Picture

#### Option 1: Direct Replacement (Simplest)
1. Get your profile picture from your PC
2. Rename it to `bot_image.jpg` (if it isn't already)
3. Copy it to: `Knightbot-MD-main/assets/bot_image.jpg`
4. Replace the existing file when prompted

#### Option 2: Upload During GitHub Push
1. Prepare your image file
2. When you clone/download the Knightbot-MD repository
3. Copy your `bot_image.jpg` to the assets folder
4. Commit and push to GitHub

### Image Recommendations

For a professional bot profile picture:
- ✅ Use a clear, recognizable image
- ✅ Make it square (512x512 recommended)
- ✅ Use JPG or PNG format
- ✅ Keep file size under 500KB
- ✅ Make sure it represents "MY WEB - LinkBot" branding

### Example Folder Structure After Update

```
Knightbot-MD-main/
├── assets/
│   ├── bot_image.jpg          ← Your new profile picture goes here
│   ├── bmc_qr.png
│   ├── stickintro.webp
│   ├── sticktag.webp
│   └── thor.png
├── commands/
├── data/
├── lib/
├── session/
├── config.js
├── index.js
├── main.js
├── package.json
├── README.md
├── settings.js
└── website/                   ← Your new pairing website
```

## Image Optimization

If your image is large, you can optimize it:

### Using Online Tools:
- TinyPNG.com - PNG/JPG compression
- Pixlr.com - Free online image editor
- Canva.com - Create professional images

### Using Command Line (ImageMagick):
```bash
convert input.jpg -resize 512x512 bot_image.jpg
```

### Using Python:
```python
from PIL import Image
img = Image.open('input.jpg')
img.thumbnail((512, 512))
img.save('bot_image.jpg')
```

## File Paths Reference

| File | Location | Purpose |
|------|----------|---------|
| bot_image.jpg | `/assets/` | Bot profile picture |
| bmc_qr.png | `/assets/` | QR code for BMC |
| stickintro.webp | `/assets/` | Sticker intro |
| sticktag.webp | `/assets/` | Sticker tag |

## After Uploading the Picture

1. Restart your bot for changes to take effect
2. The new profile picture will show on WhatsApp
3. Users will see the new image in chats

## Next Steps

1. ✅ Prepare your profile picture (512x512px, JPG/PNG)
2. ✅ Copy to `assets/bot_image.jpg`
3. ✅ Commit and push to GitHub
4. ✅ Deploy and restart the bot

---

**Bot Owner:** SiyamThanda  
**Bot Name:** MY WEB - LinkBot  
**Setup Date:** 2026-04-19
