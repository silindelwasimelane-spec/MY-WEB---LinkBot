# GitHub Upload & Deployment Guide

Complete guide to upload your customized MY WEB - LinkBot to GitHub and deploy it.

---

## 📋 Table of Contents

1. [GitHub Setup](#github-setup)
2. [Upload Bot to GitHub](#upload-bot-to-github)
3. [Upload Website to GitHub](#upload-website-to-github)
4. [Deploy Website](#deploy-website)
5. [Manage Your Repository](#manage-your-repository)

---

## GitHub Setup

### Step 1: Create a GitHub Account
1. Go to https://github.com
2. Click "Sign up"
3. Create a free account
4. Verify your email

### Step 2: Install Git on Your Computer

**For Windows:**
1. Download Git from https://git-scm.com/download/win
2. Run the installer
3. Click "Next" through all options (defaults are fine)
4. Click "Finish"

**Verify Installation:**
Open Command Prompt (or PowerShell) and type:
```bash
git --version
```

### Step 3: Configure Git
Open Command Prompt and run:
```bash
git config --global user.name "Your Name"
git config --global user.email "your.email@example.com"
```

Replace with your actual name and email.

---

## Upload Bot to GitHub

### Option 1: The Easy Way (Using GitHub Web Interface)

1. **Create a new repository:**
   - Go to https://github.com/new
   - Repository name: `MY-WEB-LinkBot` or `Knightbot-MD-custom`
   - Description: "MY WEB - LinkBot with AI, ViewOnce media recovery, and pairing website"
   - Choose "Public" (so others can use/contribute)
   - Click "Create repository"

2. **Upload files via web interface:**
   - Click "Upload files"
   - Drag and drop all files from your `Knightbot-MD-main` folder
   - Write commit message: "Initial commit: MY WEB - LinkBot customization"
   - Click "Commit changes"

3. **Add .gitignore file:**
   - Click "Add file" → "Create new file"
   - Name: `.gitignore`
   - Paste this content:
   ```
   node_modules/
   .env
   session/
   *.log
   .DS_Store
   Thumbs.db
   ```
   - Click "Commit new file"

4. **Done! Your bot is on GitHub**

### Option 2: Using Command Line (Recommended)

1. **Open Command Prompt/PowerShell**

2. **Navigate to your bot folder:**
   ```bash
   cd "path\to\Knightbot-MD-main"
   ```

3. **Initialize git repository:**
   ```bash
   git init
   ```

4. **Create .gitignore file:**
   Create a new file named `.gitignore` in your folder with:
   ```
   node_modules/
   .env
   session/
   *.log
   .DS_Store
   Thumbs.db
   ```

5. **Add all files to git:**
   ```bash
   git add .
   ```

6. **Create initial commit:**
   ```bash
   git commit -m "Initial commit: MY WEB - LinkBot with AI and ViewOnce features"
   ```

7. **Add GitHub repository as remote:**
   ```bash
   git remote add origin https://github.com/yourusername/MY-WEB-LinkBot.git
   ```
   (Replace `yourusername` with your actual GitHub username)

8. **Push to GitHub:**
   ```bash
   git branch -M main
   git push -u origin main
   ```

9. **Done! Check your repository on GitHub**

---

## Upload Website to GitHub

### Option 1: Separate Repository (Recommended - for hosting on GitHub Pages)

1. **Create new repository:**
   - Go to https://github.com/new
   - Name: `MY-WEB-LinkBot-Website`
   - Description: "Pairing website for MY WEB - LinkBot"
   - Make it public
   - Click "Create repository"

2. **Using Command Line:**
   ```bash
   cd "path\to\website"
   git init
   git add .
   git commit -m "Initial commit: LinkBot pairing website"
   git remote add origin https://github.com/yourusername/MY-WEB-LinkBot-Website.git
   git branch -M main
   git push -u origin main
   ```

3. **Enable GitHub Pages:**
   - Go to your repository Settings
   - Scroll to "GitHub Pages"
   - Select "Deploy from a branch"
   - Choose "main" branch
   - Click "Save"
   - Your site will be at: `https://yourusername.github.io/MY-WEB-LinkBot-Website`

### Option 2: Website in Bot Repository

1. **Website is already in `website/` folder**
2. **Push the whole folder as part of bot repository**
3. **Deploy separately using recommendations below**

---

## Deploy Website

### Option 1: GitHub Pages (Free)

**Already covered above**
- Website URL: `https://yourusername.github.io/MY-WEB-LinkBot-Website`
- No additional configuration needed

### Option 2: Netlify (Free, Simple)

1. **Go to https://www.netlify.com**
2. **Click "Sign up"** and choose "GitHub"
3. **Authorize Netlify** to access your repositories
4. **Click "New site from Git"**
5. **Select your repository** (MY-WEB-LinkBot-Website)
6. **Configure build settings:**
   - Build command: (leave empty)
   - Publish directory: `./` or `./website`
7. **Click "Deploy site"**
8. **Your site will be live** at a URL like `brilliant-name-abc123.netlify.app`

### Option 3: Vercel (Free, Recommended)

1. **Go to https://vercel.com**
2. **Click "Sign up"** with GitHub
3. **Authorize Vercel**
4. **Click "New Project"**
5. **Import your GitHub repository**
6. **Vercel auto-detects settings** (no configuration needed)
7. **Click "Deploy"**
8. **Your site is live!** You can also add a custom domain

### Option 4: Firebase Hosting (Free)

1. **Go to https://firebase.google.com**
2. **Sign in with Google**
3. **Create a new project**
4. **Install Firebase CLI:**
   ```bash
   npm install -g firebase-tools
   ```
5. **Login to Firebase:**
   ```bash
   firebase login
   ```
6. **In your website folder, run:**
   ```bash
   firebase init hosting
   ```
7. **Follow prompts**, choose `website` or `dist` as public directory
8. **Deploy:**
   ```bash
   firebase deploy
   ```

---

## Manage Your Repository

### Basic Git Commands

**Check status:**
```bash
git status
```

**View changes:**
```bash
git diff
```

**Update your local code:**
```bash
git pull origin main
```

**Make changes and push:**
```bash
git add .
git commit -m "Your message describing changes"
git push origin main
```

**Create a new branch:**
```bash
git checkout -b feature/new-feature
git push -u origin feature/new-feature
```

### Adding Your Profile Picture

1. **Prepare your image:**
   - Save as `bot_image.jpg` (512x512 recommended)

2. **Add to repository:**
   ```bash
   # Copy your image to assets folder
   copy "path\to\your\image.jpg" "assets\bot_image.jpg"
   
   # Commit and push
   git add assets/bot_image.jpg
   git commit -m "Add custom bot profile picture"
   git push origin main
   ```

3. **Update website image (optional):**
   - Add logo image to `website/assets/` folder
   - Reference it in `website/index.html`

### Creating a README.md

1. **Create a professional README:**
   ```bash
   # MY WEB - LinkBot

   A powerful WhatsApp bot with AI integration and advanced features.

   ## Features
   - 🤖 AI powered (GPT & Gemini)
   - 👁️ View once media recovery
   - ⚙️ Advanced commands
   - 🔒 Secure and private

   ## Installation

   [Your installation steps...]

   ## Commands

   [Your bot commands...]

   ## Support

   - Email: sillindelwasimelane@gmail.com
   - WhatsApp: +27765160521
   - Channel: https://whatsapp.com/channel/0029Vb7bGEQIHphDP72VD81b

   ## License

   © 2026 MY WEB - LinkBot
   ```

2. **Push to GitHub:**
   ```bash
   git add README.md
   git commit -m "Add comprehensive README"
   git push origin main
   ```

---

## Useful Links

| Service | URL | Use Case |
|---------|-----|----------|
| GitHub | https://github.com | Code hosting |
| Git Download | https://git-scm.com | Version control |
| Netlify | https://netlify.com | Website hosting |
| Vercel | https://vercel.com | Website hosting |
| Firebase | https://firebase.google.com | Website hosting |
| GitHub Pages | https://pages.github.com | Free website hosting |

---

## Troubleshooting

### Git not found
- Install Git from https://git-scm.com
- Restart your Command Prompt after installation

### "Permission denied (publickey)"
- You need to generate SSH keys
- Follow: https://docs.github.com/en/authentication/connecting-to-github-with-ssh

### Large files error
- Git has a 100MB limit on files
- Remove from repository and use Git LFS if needed

### Website not updating after push
- Wait 5-10 minutes for GitHub Pages to rebuild
- Clear your browser cache (Ctrl+Shift+Del)
- Check build status under repository Settings → Actions

---

## Summary

### Timeline for Full Setup

1. **GitHub Setup** - 5 minutes
2. **Upload Bot** - 10 minutes
3. **Upload Website** - 5 minutes
4. **Deploy Website** - 15 minutes
5. **Add Profile Picture** - 5 minutes

**Total: ~40 minutes**

### What You'll Have

✅ Bot code on GitHub  
✅ Website on GitHub  
✅ Website hosted and live  
✅ Custom profile picture  
✅ Professional README  
✅ Share link with users: `yourusername.github.io/MY-WEB-LinkBot-Website`

---

## Next Steps

1. Download and install Git
2. Create GitHub account
3. Follow the upload steps above
4. Share your GitHub link with others
5. Keep updating and improving your bot!

---

**Bot Owner:** SiyamThanda  
**Bot Name:** MY WEB - LinkBot  
**Version:** 3.1.0  
**Last Updated:** 2026-04-19

For support: sillindelwasimelane@gmail.com
