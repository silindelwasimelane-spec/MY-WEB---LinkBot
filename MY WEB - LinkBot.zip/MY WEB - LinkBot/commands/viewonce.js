const { downloadContentFromMessage } = require('@whiskeysockets/baileys');

async function viewonceCommand(sock, chatId, message) {
    try {
        // Extract quoted message from your structure
        const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        
        if (!quoted) {
            return await sock.sendMessage(chatId, { 
                text: '❌ Please reply to a view-once photo, video, or voice note.' 
            }, { quoted: message });
        }

        const quotedImage = quoted?.imageMessage;
        const quotedVideo = quoted?.videoMessage;
        const quotedAudio = quoted?.audioMessage; // Voice note/PTT
        const quotedViewOnceMessage = quoted?.viewOnceMessage; // View once message container

        let success = false;

        // Handle standard view-once image
        if (quotedImage && quotedImage.viewOnce) {
            try {
                const stream = await downloadContentFromMessage(quotedImage, 'image');
                let buffer = Buffer.from([]);
                for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);
                await sock.sendMessage(chatId, { 
                    image: buffer, 
                    fileName: 'viewonce-photo.jpg', 
                    caption: quotedImage.caption || '📸 View Once Photo' 
                }, { quoted: message });
                success = true;
            } catch (e) {
                console.error('Error downloading view-once image:', e);
            }
        }

        // Handle standard view-once video
        if (quotedVideo && quotedVideo.viewOnce) {
            try {
                const stream = await downloadContentFromMessage(quotedVideo, 'video');
                let buffer = Buffer.from([]);
                for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);
                await sock.sendMessage(chatId, { 
                    video: buffer, 
                    fileName: 'viewonce-video.mp4', 
                    caption: quotedVideo.caption || '🎥 View Once Video' 
                }, { quoted: message });
                success = true;
            } catch (e) {
                console.error('Error downloading view-once video:', e);
            }
        }

        // Handle view-once voice notes/PTT (audio)
        if (quotedAudio && quotedAudio.viewOnce) {
            try {
                const stream = await downloadContentFromMessage(quotedAudio, 'audio');
                let buffer = Buffer.from([]);
                for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);
                await sock.sendMessage(chatId, { 
                    audio: buffer, 
                    ptt: true, // Mark as voice note
                    mimetype: 'audio/ogg;codecs=opus'
                }, { quoted: message });
                await sock.sendMessage(chatId, { 
                    text: '🎤 View Once Voice Note Recovered' 
                }, { quoted: message });
                success = true;
            } catch (e) {
                console.error('Error downloading view-once audio:', e);
            }
        }

        // Handle view-once message wrapper
        if (quotedViewOnceMessage) {
            try {
                const messageContent = quotedViewOnceMessage.message;
                
                if (messageContent?.imageMessage) {
                    const stream = await downloadContentFromMessage(messageContent.imageMessage, 'image');
                    let buffer = Buffer.from([]);
                    for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);
                    await sock.sendMessage(chatId, { 
                        image: buffer, 
                        fileName: 'viewonce-photo.jpg' 
                    }, { quoted: message });
                    success = true;
                } else if (messageContent?.videoMessage) {
                    const stream = await downloadContentFromMessage(messageContent.videoMessage, 'video');
                    let buffer = Buffer.from([]);
                    for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);
                    await sock.sendMessage(chatId, { 
                        video: buffer, 
                        fileName: 'viewonce-video.mp4' 
                    }, { quoted: message });
                    success = true;
                } else if (messageContent?.audioMessage) {
                    const stream = await downloadContentFromMessage(messageContent.audioMessage, 'audio');
                    let buffer = Buffer.from([]);
                    for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);
                    await sock.sendMessage(chatId, { 
                        audio: buffer, 
                        ptt: true, 
                        mimetype: 'audio/ogg;codecs=opus'
                    }, { quoted: message });
                    await sock.sendMessage(chatId, { 
                        text: '🎤 View Once Voice Note Recovered' 
                    }, { quoted: message });
                    success = true;
                }
            } catch (e) {
                console.error('Error handling view-once message:', e);
            }
        }

        // If nothing was recovered
        if (!success) {
            await sock.sendMessage(chatId, { 
                text: '❌ Could not recover view-once content. Please make sure you replied to a view-once photo, video, or voice note.' 
            }, { quoted: message });
        }

    } catch (error) {
        console.error('ViewOnce Command Error:', error);
        await sock.sendMessage(chatId, { 
            text: '❌ An error occurred while processing the view-once content.' 
        }, { quoted: message });
    }
}

module.exports = viewonceCommand;