const axios = require('axios');
const fetch = require('node-fetch');
const settings = require('../settings');

async function aiCommand(sock, chatId, message) {
    try {
        const text = message.message?.conversation || message.message?.extendedTextMessage?.text;
        
        if (!text) {
            return await sock.sendMessage(chatId, { 
                text: "🤖 *AI Commands*\n\n.gpt <question> - Use OpenAI GPT (powered by SiyamThanda)\n.gemini <question> - Use Google Gemini\n\n*Example:*\n.gpt what is machine learning?\n.gemini write a python code"
            }, {
                quoted: message
            });
        }

        // Get the command and query
        const parts = text.split(' ');
        const command = parts[0].toLowerCase();
        const query = parts.slice(1).join(' ').trim();

        if (!query) {
            return await sock.sendMessage(chatId, { 
                text: "❌ Please provide a question\n\n*Example:*\n.gpt what is Python?"
            }, {quoted:message});
        }

        try {
            // Show processing message
            await sock.sendMessage(chatId, {
                react: { text: '⏳', key: message.key }
            });

            if (command === '.gpt') {
                // Use OpenAI API if key is available, otherwise fallback
                if (settings.openAIApiKey && settings.openAIApiKey.includes('sk-')) {
                    try {
                        const response = await axios.post(
                            'https://api.openai.com/v1/chat/completions',
                            {
                                model: 'gpt-3.5-turbo',
                                messages: [
                                    {
                                        role: 'user',
                                        content: query
                                    }
                                ],
                                max_tokens: 500,
                                temperature: 0.7
                            },
                            {
                                headers: {
                                    'Authorization': `Bearer ${settings.openAIApiKey}`,
                                    'Content-Type': 'application/json'
                                }
                            }
                        );

                        const answer = response.data.choices[0].message.content;
                        await sock.sendMessage(chatId, {
                            text: `🤖 *OpenAI GPT Response*\n\n${answer}\n\n_Powered by MY WEB - LinkBot_`
                        }, {
                            quoted: message
                        });
                        return;
                    } catch (openaiError) {
                        console.log('OpenAI API error, trying fallback...', openaiError.message);
                        // Fallback to alternate API
                    }
                }

                // Fallback: Call alternate GPT API
                const response = await axios.get(`https://zellapi.autos/ai/chatbot?text=${encodeURIComponent(query)}`);
                
                if (response.data && response.data.status && response.data.result) {
                    const answer = response.data.result;
                    await sock.sendMessage(chatId, {
                        text: `🤖 *AI Response*\n\n${answer}`
                    }, {
                        quoted: message
                    });
                    
                } else {
                    throw new Error('Invalid response from API');
                }
            } else if (command === '.gemini') {
                const apis = [
                    `https://vapis.my.id/api/gemini?q=${encodeURIComponent(query)}`,
                    `https://api.siputzx.my.id/api/ai/gemini-pro?content=${encodeURIComponent(query)}`,
                    `https://api.ryzendesu.vip/api/ai/gemini?text=${encodeURIComponent(query)}`,
                    `https://zellapi.autos/ai/chatbot?text=${encodeURIComponent(query)}`,
                    `https://api.giftedtech.my.id/api/ai/geminiai?apikey=gifted&q=${encodeURIComponent(query)}`,
                    `https://api.giftedtech.my.id/api/ai/geminiaipro?apikey=gifted&q=${encodeURIComponent(query)}`
                ];

                for (const api of apis) {
                    try {
                        const response = await fetch(api);
                        const data = await response.json();

                        if (data.message || data.data || data.answer || data.result) {
                            const answer = data.message || data.data || data.answer || data.result;
                            await sock.sendMessage(chatId, {
                                text: `✨ *Gemini Response*\n\n${answer}\n\n_Powered by MY WEB - LinkBot_`
                            }, {
                                quoted: message
                            });
                            
                            return;
                        }
                    } catch (e) {
                        continue;
                    }
                }
                throw new Error('All Gemini APIs failed');
            }
        } catch (error) {
            console.error('API Error:', error);
            await sock.sendMessage(chatId, {
                text: "❌ Failed to get response. Please try again later.",
                contextInfo: {
                    mentionedJid: [message.key.participant || message.key.remoteJid],
                    quotedMessage: message.message
                }
            }, {
                quoted: message
            });
        }
    } catch (error) {
        console.error('AI Command Error:', error);
        await sock.sendMessage(chatId, {
            text: "❌ An error occurred. Please try again later.",
            contextInfo: {
                mentionedJid: [message.key.participant || message.key.remoteJid],
                quotedMessage: message.message
            }
        }, {
            quoted: message
        });
    }
}

module.exports = aiCommand; 